(function($) {
	"use strict";

	$('#ad_catsdiv').hide();
	$('#ad_tagsdiv').hide();
	$('#ad_conditiondiv').hide();
	$('#ad_typediv').hide();
	$('#ad_warrantydiv').hide();
	
})( jQuery );
